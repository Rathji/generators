# Rebranding this package as *your* BGN app

Everything user-visible is driven from **`main.pjs`** — the HTML just reads it
at render time — so rebranding is mostly editing one file.

## 1. Names

Edit `main.pjs`:

- `$meta.title` and `gameTitle` → your game/app name
- `$meta.description` + `tags` → what it is (used for SEO / listing page)
- `gameTagline` → one-liner under the hero title
- `gameKicker` → the small bold line above the title
- `gameGenre` (e.g. "Strategy") and `gamePlayers` ("2 players") → the hero tags

The hero title, nav title and lobby all read from these, so there are no
hardcoded names elsewhere — except the two comments that say "BGN BLANK
TEMPLATE" in `index.html` (top of file and the `<style>` block), which you can
leave or rename.

## 2. Look & feel

- `accentColor` — the whole theme retints through the `--bgn-accent` CSS
  variable (gold default `#d4af37`).
- `heroImage` — background image for the hero (also used as `$meta.image` for
  the listing page). Point it at a permanent URL (e.g. the upload service).
- The design system lives in `style/bgn.css`. To change the shared look for a
  single app, override the classes in `index.html`; to change it network-wide,
  edit `style/bgn.css` and re-host it, then update the `<link>` URL in every
  game.

## 3. Network / hub

- `hubUrl` — where the "← Boardgame Network" nav link goes. For a BGN app keep
  it on the network hub; the footer "Part of The Boardgame Network · Browse
  the shelf" uses the same URL.
- If you are **not** shipping as a BGN app, also remove/replace the BGN brand
  mark (nav `<a>` with the star SVG, the footer text) in `index.html`.

## 4. Your game

The client `game` object (see `index.html`) already tracks everything the
table needs:

```
mode, myRole, roomCode, socket, sockOpen, serverTurn, first, status,
oppPresent, over, winner, reason, locked
```

- `turnRoleFor(n)` → `"host" | "guest"` for completed-turn count `n`
  (`first` decides who goes first). You may act when
  `turnRoleFor(game.serverTurn) === game.myRole` (online) — the button wiring
  in `passTurn()` is the working example.
- Play the turn locally, then:
  `rpc("move", JSON.stringify({code: game.roomCode, evt: game.serverTurn, data: <compact state string>}))`
  and call `refreshFromServer()` to pull the authoritative snap.
- Every snap (broadcast or pulled) lands in `applyServerSnap(s)` — apply
  `s.snapshot` there to rebuild your state, and handle `s.status === 3` for
  game over.
- To end a match: `rpc("endGame", JSON.stringify({code, winner}))` with
  `winner` = `"host" | "guest" | "draw"`.
- Keep your snapshot compact: the durable per-room slot is 1024 bytes total.
  `JSON.stringify` of small arrays (e.g. `{v:1, o:[…], a:[…]}`) fits; for
  heavier state use a versioned binary string.

## 5. Durable state layout (server)

The server stores each room in a 1024-byte slot in the plugin `state` bytes
(the layout is commented in full in `index.html`). Key fields: status, room
code, `first`, state version byte, last-active timestamp, winner, reason,
turn counter (uint16), snapshot length + snapshot bytes.

**If you change this layout, bump `STATE_VERSION`** — old-version slots are
reclaimed automatically on load, so games started under the old layout simply
expire. `MAX_ROOMS` derives from `state.length`, so it adapts if the plugin's
byte budget grows.

## 6. Test & ship

- In the editor, sockets use a **single-tab emulator** (unsaved). Full
  multi-tab behaviour only exists after the generator is **saved** and running
  on the production server.
- After a server-code change, browser sockets close with `1012` — the client
  auto-reconnects and rejoins via `rejoinRoom()`.
- Socket close `4403` means online isn't available on that page (the
  perchance-only restriction). Treat it as permanent — no reconnect loop.
- Everything is public source. No secrets anywhere.

## 7. Checklist

- [ ] `main.pjs`: title, description, tags, tagline, kicker, genre, players
- [ ] `main.pjs`: `accentColor`, `heroImage` (+ `$meta.image`)
- [ ] `main.pjs`: `hubUrl` (BGN hub, or removed if not a BGN app)
- [ ] `index.html`: replace `#stageEl` placeholder with your game
- [ ] `index.html`: wire `move` / `endGame` into your game logic
- [ ] Optional: remove/rename BGN brand mark + footer if not a BGN app
- [ ] Save, then test with two real tabs on the production server
