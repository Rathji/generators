# BGN Blank Template — export package

A ready-made **two-player online table** for the Boardgame Network (or any
perchance-based app): rooms, room codes, turn order, presence, rematch and
claim-win — **with no game logic**. Bring your own game.

## Contents

| File | What it is |
| --- | --- |
| `main.pjs` | Page config (title, tagline, colors, hero, hub link) + the server-plugin import |
| `index.html` | Lobby + game table + authoritative table server (`<script type="text/x-server-plugin">`) + client |
| `style/bgn.css` | The BGN design system (source). A copy is also hosted — see the `<link>` in `index.html` |
| `BRANDING.md` | Step-by-step guide to make it *your* BGN app |

## Quick start (perchance)

1. Create a new generator on perchance.
2. Paste `main.pjs` into the pjs pane and `index.html` into the HTML pane.
3. Save. You now have a working **Local** (hotseat) and **Online** table.

For a non-perchance host, `index.html` works as a normal page too, but online
play uses perchance's server-plugin (see "Notes" below).

## How it works

- **Server** (`<script type="text/x-server-plugin">` in index.html) is the
  authoritative table: 5-letter room codes, host + guest, strict turn
  sequencing (host first; a rematch flips), presence/disconnect handling,
  winner + reason, and one **full-game snapshot** per room kept in durable
  `state` bytes (survives restarts).
- **Client** lobby → create / join room → table with two player slots, turn
  display, turn log and a "Pass the turn" demo. No game ships.
- **The intended game pattern** (the recommended, low-trust way to build on
  this): the acting player plays their whole turn locally, then submits a
  compact full-state snapshot via `move`. The server sequences it (one per
  turn) and fans it out; the other client just applies it. Declare a winner
  with `endGame`. The server never needs to know your game's rules.

## Server RPC API

Each RPC takes one string and returns a JSON string. All defined in
`index.html` — read that source, it is your reference.

| Method | Args | Returns |
| --- | --- | --- |
| `createRoom` | — | `{ok, code, role:"host", snap}` |
| `joinRoom` | `code` | `{ok, role, snap}` |
| `getRoom` | `code` | `{ok, snap}` |
| `move` | `{code, evt, data}` | `{ok}` — submit your turn payload. `evt` must equal the server turn counter; alternation is enforced |
| `endGame` | `{code, winner}` | `{ok}` — winner: `"host" | "guest" | "draw"` (reason `end`) |
| `resign` | — | `{ok}` — other side wins, reason `resign` |
| `rematch` | — | `{ok}` — resets turn + snapshot, flips `first` |
| `claimWin` | — | `{ok}` — only when opponent is disconnected |
| `leave` | — | `{ok}` — opponent wins by forfeit if playing |

`snap = {code, status, snapshot, first, turn, hostIn, guestIn, winner, reason}`
where `status` is 1 waiting / 2 playing / 3 finished, `first` is who moves
first (0 = host), and `turn` is the completed-turn counter.

## Adding your game (short version)

1. Replace the `#stageEl` placeholder in `index.html` with your board/UI.
2. Track whose turn it is: when `turnRoleFor(serverTurn) === game.myRole` you
   may act. Play out the turn, then submit
   `rpc("move", JSON.stringify({code, evt: game.serverTurn, data:<compact state>}))`.
3. On every snap you receive, apply `snap.snapshot` to rebuild your state.
4. When someone wins, `rpc("endGame", JSON.stringify({code, winner}))`.

Full client integration notes and the durable-state slot layout are in
`BRANDING.md`.

## Notes & limits

- **The server script is public source** — every visitor can read it. Never
  put passwords, tokens or keys in it, or anywhere client-visible.
- Two players per room (host/guest).
- The per-room durable slot is 1024 bytes; keep your snapshot under ~1000
  bytes (compact JSON or a versioned binary string).
- `move` is rate-limited (~300 ms per connection) and `evt` is a stale-check;
  a rejected move is safe to resubmit after refreshing from the server.
- Online play requires the whole page frame chain on perchance.org; embedded
  on external sites the socket closes with code `4403` (treat as permanent,
  do not reconnect-loop).
- The BGN look comes from `style/bgn.css`; the whole theme retints through the
  `--bgn-accent` CSS variable (set from `accentColor` in main.pjs).

## License / brand

The "Boardgame Network" name, logo mark and footer text are the network's
brand. If you are shipping as a BGN app, keep the hub link (`hubUrl`) pointing
at the network hub. If not, remove the BGN branding in `BRANDING.md` and the
footer.
